package com.example.permission_helper

object Constant {

    const val ANDROID_ID_NOT_FOUND = "ANDROID_ID_NOT_FOUND"

}