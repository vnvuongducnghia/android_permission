package com.example.permission_helper.data.model

class Hero {
}