package com.example.permission_helper.data.model

/**
 * Created by nghia.vuong on 05,October,2020
 */
class Nghia {
    private var Tuoi = 25
    private var ChieuCao = "1m78"
}