package com.example.permission_helper.data.source.remote.api_setting

object ApiLink {

    /*Demo*/
    val getUser  = "https://jsonplaceholder.typicode.com/posts/{userId}"
}