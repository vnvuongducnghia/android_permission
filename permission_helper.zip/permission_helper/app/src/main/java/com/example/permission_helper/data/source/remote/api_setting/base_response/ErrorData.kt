package com.example.permission_helper.data.source.remote.api_setting.base_response

class ErrorData(var data: String, var statusCode: Int) {
}