package com.example.permission_helper.ui

interface BasePresenter {
    fun start()
    fun end()
}