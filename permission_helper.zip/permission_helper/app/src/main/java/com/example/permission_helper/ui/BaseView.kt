package com.example.permission_helper.ui

interface BaseView<T> {
    var presenter: T
}