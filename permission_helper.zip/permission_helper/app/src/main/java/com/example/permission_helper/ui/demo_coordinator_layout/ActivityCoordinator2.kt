package com.example.permission_helper.ui.demo_coordinator_layout

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.permission_helper.R

class ActivityCoordinator2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coordinator2)
    }
}
