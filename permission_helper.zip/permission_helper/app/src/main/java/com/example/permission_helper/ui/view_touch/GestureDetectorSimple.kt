package com.example.permission_helper.ui.view_touch

import android.view.GestureDetector

class GestureDetectorSimple: GestureDetector.SimpleOnGestureListener() {

}